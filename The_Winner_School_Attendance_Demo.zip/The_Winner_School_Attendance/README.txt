THE WINNER SCHOOL (ISLAMIC CAMPUS) - Attendance Demo
Open index.html in Chrome.
Demo login:
Admin: admin / winner123
Teacher: teacher / teach123

Features: class-wise attendance, student register, daily report, CSV export, JSON backup/restore, prefilled WhatsApp links.
This is a browser-local demo only (not a hosted cloud app); data remains in the same browser/device.
For real online multi-device login, secure backend/database and hosting are required. For automatic WhatsApp delivery, connect Meta WhatsApp Business Platform/API on backend, use approved templates and consent. Do not store API tokens in browser code.
Change demo passwords and arrange secure deployment before real student data use.
